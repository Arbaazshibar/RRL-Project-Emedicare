package com.nt.medicare.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.nt.medicare.entity.Medicines;

@Repository
public interface MedicineRepository extends JpaRepository<Medicines,Integer> {
	
	List<Medicines> findByStatus(String status);
	List<Medicines> findByType(String type);
	
}
