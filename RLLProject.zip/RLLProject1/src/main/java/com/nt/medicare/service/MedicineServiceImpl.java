package com.nt.medicare.service;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.nt.medicare.entity.Medicines;
import com.nt.medicare.repository.MedicineRepository;


@Service
public class MedicineServiceImpl implements IMedicineService{
	@Autowired
	private MedicineRepository medicineRepository;
	
	@Autowired
	private Environment env;

	
	@Override
	public List<Medicines> getMedicineDetails() {
		List<Medicines> medicines = medicineRepository.findAll();
		return medicines;
	}
	
	
	@Override
	public List<Medicines> getAllActiveDetails(String status) {
		return medicineRepository.findByStatus(status);
	}
	
	
	@Override
	public void deleteMedicines(int medicineId) {
		medicineRepository.deleteById(medicineId);
	}
	
	
	@Override
	public List<Medicines> getAllByType(String type) {
		return medicineRepository.findByType(type);
	}

	@Override
	public Medicines findById(int medicineId) {
		Medicines m = medicineRepository.findById(medicineId).get();
		return m;
	}


@Override
public Medicines insertMedicines(Medicines medicines) {
	return medicineRepository.save(medicines);
	
}

@Override
public void updateMedicines(Medicines medicine) {
	medicineRepository.save(medicine);
}




@Override
public Page<Medicines> getPageMedicineDetails(Pageable pageable) {
	return medicineRepository.findAll(pageable);
}



@Override
public List<String> getAllCatogories(String types) {
	String catogories=env.getRequiredProperty(types);
	System.out.println(catogories);
	List<String> catList=Arrays.asList(catogories.split(","));
	System.out.println(catList);
	return catList;	
}









}
