package com.nt.medicare.service;

import java.util.List;
import java.util.Set;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.nt.medicare.entity.Medicines;

public interface IMedicineService {
	
	
	List<Medicines> getMedicineDetails();
	List<Medicines> getAllByType(String type);
	Medicines findById(int medicineId);
	
	
	public Medicines insertMedicines(Medicines medicines);
	void updateMedicines(Medicines medicines);
	void deleteMedicines(int medicineId);
	
	
	Page<Medicines> getPageMedicineDetails(Pageable pageable);
	
	List<Medicines> getAllActiveDetails(String status);


	List<String> getAllCatogories(String types);

}
