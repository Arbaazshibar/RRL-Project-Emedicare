package com.nt.admin.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nt.admin.entity.Admin;
import com.nt.admin.entity.AdminAuthenticationStatus;
import com.nt.admin.service.AdminService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/v1")
public class AdminController {
	
@Autowired
private AdminService adminService;

@PostMapping("/admins")
public ResponseEntity insert(@RequestBody Admin admin) {
	adminService.insertAdmin(admin);
	return new ResponseEntity<>(HttpStatus.CREATED);
}
@PostMapping("/admin")
public ResponseEntity<AdminAuthenticationStatus> authenticate(@RequestBody Admin admin) {
	AdminAuthenticationStatus authStatus=adminService.getAdminStatus(admin.getAdmin(),admin.getPassword());
	return new ResponseEntity<AdminAuthenticationStatus>(authStatus,HttpStatus.ACCEPTED);
	
}
}
