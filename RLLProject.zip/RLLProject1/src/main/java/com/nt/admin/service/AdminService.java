package com.nt.admin.service;


import com.nt.admin.entity.Admin;
import com.nt.admin.entity.AdminAuthenticationStatus;

public interface AdminService {
	void insertAdmin(Admin admin);
	AdminAuthenticationStatus getAdminStatus(String admin,String password);

}
