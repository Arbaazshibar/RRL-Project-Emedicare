package com.nt.cantactUs.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nt.cantactUs.entity.CantactUs;
import com.nt.cantactUs.repository.CantactUsRepository;

@Service
public class CantactUsServiceImpl implements ICantactUsService {
	@Autowired
	private CantactUsRepository contactUsRepository;
		
	
	@Override
	public void insertMsg(CantactUs contactUs) {
		contactUsRepository.save(contactUs);
		
	}
	
	@Override
	public List<CantactUs> getQueries() {

		List<CantactUs> C = contactUsRepository.findAll();
		return C;
	}

}
