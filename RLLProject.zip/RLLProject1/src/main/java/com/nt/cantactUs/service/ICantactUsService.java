package com.nt.cantactUs.service;

import java.util.List;

import com.nt.cantactUs.entity.CantactUs;


public interface ICantactUsService {
	void insertMsg(CantactUs contactUs);
	List<CantactUs> getQueries();

}
