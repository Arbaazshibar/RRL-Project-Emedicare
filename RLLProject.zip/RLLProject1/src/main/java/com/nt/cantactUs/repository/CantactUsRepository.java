package com.nt.cantactUs.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nt.cantactUs.entity.CantactUs;

public interface CantactUsRepository extends JpaRepository<CantactUs, Integer>{

}
