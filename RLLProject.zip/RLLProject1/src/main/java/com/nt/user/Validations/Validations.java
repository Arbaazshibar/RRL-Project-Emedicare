package com.nt.user.Validations;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.nt.user.entity.User;

@Component
public class Validations implements Validator {

	@Override
	public boolean supports(Class<?> clazz) {
		return clazz.isAssignableFrom(User.class);
	}

	@Override
	public void validate(Object target, Errors errors) {
		User us=(User)target;
      System.out.println("Validations.validate()");
		
      
      
      if(us.getFirst_name().isBlank() || us.getFirst_name()==null) {
			errors.reject("first_name","phd");
		}
		
		
		if(us.getMobile_no().length()==10) {
			errors.reject("mobile_no","phd");
		}
		
		
		
		if(us.getPassword().length()<8) {
			errors.reject("password","phd");
		}
		
		if(us.getGender().equalsIgnoreCase("male") || us.getGender().equalsIgnoreCase("female") ) {
			errors.reject("gender","phd");
		}
	

  }
}
