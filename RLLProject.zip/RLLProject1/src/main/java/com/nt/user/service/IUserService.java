package com.nt.user.service;

import com.nt.user.authentication.AuthenticationStatus;
import com.nt.user.entity.User;

public interface IUserService {
	
	void insertUser(User user);
	 AuthenticationStatus getStatus(String username,String password);
	 User getUser(String username);
	 User updateUser(String username, User user);

}
