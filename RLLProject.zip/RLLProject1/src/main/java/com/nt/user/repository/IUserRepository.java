package com.nt.user.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nt.user.entity.User;

public interface IUserRepository extends JpaRepository<User, Integer> {
	
	User findByUsernameAndPassword(String username,String password );
	User findByUsername(String username);

}
