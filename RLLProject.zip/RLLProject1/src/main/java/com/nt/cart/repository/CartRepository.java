package com.nt.cart.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nt.cart.entity.Cart;

public interface CartRepository extends JpaRepository<Cart, Integer> {

}
