package com.nt.cart.service;

import java.util.List;

import com.nt.cart.entity.Cart;


public interface ICartService {

	void insertCart(Cart cart);
	void addToCart(Cart Citem);
	void deleteCart(int medicineId);
	List<Cart>getCart();
	Cart findById(int medicineId);
}
