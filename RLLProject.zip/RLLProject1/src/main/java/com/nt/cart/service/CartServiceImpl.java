package com.nt.cart.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nt.cart.entity.Cart;
import com.nt.cart.repository.CartRepository;

@Service
public class CartServiceImpl implements ICartService {
	@Autowired
	private CartRepository cartRepository;

	@Override
	public void addToCart(Cart Citem) {
		cartRepository.save(Citem);
	}

	@Override
	public void deleteCart(int medicineId) {
	cartRepository.deleteById(medicineId);
		
	}

	@Override
	public List<Cart> getCart() {
		List<Cart> cart = cartRepository.findAll();
		return cart;
	}

	@Override
	public void insertCart(Cart cart) {
		cartRepository.save(cart);
		
	} 

	@Override
	public Cart findById(int medicineId) {
		Cart C = cartRepository.findById(medicineId).get();
		return C;
	} 
}
