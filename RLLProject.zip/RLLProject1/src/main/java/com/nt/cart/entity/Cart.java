package com.nt.cart.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Cart {
	@Id
	private int medicineId;
	private String medicineName;
	private int price;
	private String description;
	public Cart() {
		super();
	}
	public Cart(int medicineId, String medicineName, int price, String description) {
		super();
		this.medicineId = medicineId;
		this.medicineName = medicineName;
		this.price = price;
		this.description = description;
	}
	public int getMedicineId() {
		return medicineId;
	}
	public void setMedicineId(int medicineId) {
		this.medicineId = medicineId;
	}
	public String getMedicineName() {
		return medicineName;
	}
	public void setMedicineName(String medicineName) {
		this.medicineName = medicineName;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	@Override
	public String toString() {
		return "Cart [medicineId=" + medicineId + ", medicineName=" + medicineName + ", price=" + price
				+ ", description=" + description + "]";
	}
	
	

}
