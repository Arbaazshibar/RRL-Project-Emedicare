package com.nt;


import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.junit.runners.Suite.SuiteClasses;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.nt.user.authentication.AuthenticationStatus;
import com.nt.user.entity.User;
import com.nt.user.repository.IUserRepository;
import com.nt.user.service.IUserService;

@RunWith(SpringRunner.class)
@SuiteClasses({})
@SpringBootTest
public class UserSignUpSignIn {

	@Autowired
	IUserService userService;
	
	@Autowired
	IUserRepository userRepository;
	
	
	@Test
	@DisplayName("SigUp with valid details")
	public void signUpTest(){
		User user = new User();
		user.setFirst_name("First");
		user.setLast_name("UserTest");
		user.setMobile_no("9876543210876674847");
		user.setDob("25-02-2025");
		user.setUsername("anil@12345");
		user.setPassword("Ansol");
		user.setGender("Male");
		
		userService.insertUser(user);
	}
	
	@Test
	@DisplayName("SigIn with valid details")
	public void signInTest(){
		String username = "anilkumar@123";
		String password = "Ansol";
		
		AuthenticationStatus res = userService.getStatus(username, password);
	}
	
}
