package com.nt;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RllProjectApplicationTests {

	
	
	

}
