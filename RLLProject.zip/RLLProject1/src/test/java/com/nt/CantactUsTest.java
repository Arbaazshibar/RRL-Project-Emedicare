package com.nt;


import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.junit.runners.Suite.SuiteClasses;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.nt.cantactUs.entity.CantactUs;
import com.nt.cantactUs.repository.CantactUsRepository;
import com.nt.cantactUs.service.ICantactUsService;


@RunWith(SpringRunner.class)
@SuiteClasses({})
@SpringBootTest
public class CantactUsTest {

	@Autowired
	ICantactUsService cs;
	
	@Autowired
	CantactUsRepository cr;
	
	
	@Test
	@DisplayName("GET All details")
	public void getallqueriesTest(){

	    List<CantactUs> ks = cs.getQueries();
	 double rs =ks.size();
	 assertTrue(rs>0);
	}
	@Test
	@DisplayName("Insert Message")
	public void contactusinsert() {
		CantactUs cd = new CantactUs();
		cd.setcId(5);
		cd.setName("Anil");
		cd.setEmailId("jayanth@gmail.com");
		cd.setContactNo(1234567891);
		cd.setDescription("regarding policies");
		cr.save(cd);
		assertTrue(cd.getcId()>0);
		
	}
	
}
